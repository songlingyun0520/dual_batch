"""CPU control-flow check using actual forward bodies; NOT an NPU accuracy test."""
import ast
import os
from pathlib import Path
from types import SimpleNamespace as NS

from patch_sfa_defer_attention import transform


class Tensor:
    shape = (4, 128)
    def split(self, *args, **kwargs): return Tensor(), Tensor()
    def view(self, *args): return self
    def __getitem__(self, key): return self
    def __setitem__(self, key, value): pass
    def contiguous(self): return self
    def fill_(self, value): return self


def run(source, enabled, state="decode", **overrides):
    calls = []
    def record(name, result=None):
        def call(*args, **kwargs):
            calls.append(name)
            return result
        return call
    class Linear:
        weight = Tensor()
        def __init__(self, name): self.name = name
        def __call__(self, *args):
            calls.append(self.name)
            return (Tensor(),)
    impl = NS(
        enable_mlapo=False, enable_dsa_cp=False,
        enable_dsa_cp_with_layer_shard=False, enable_dsa_cp_with_o_proj_tp=False,
        enable_sfa_prolog_v3=False, enable_sp=False, enable_sparse_sfa_c8=False,
        enable_sparse_li_c8=False, use_sparse_c8_indexer=False,
        has_indexer=True, skip_topk=False, use_index_cache=False,
        is_kv_producer=False, vllm_config=NS(kv_transfer_config=None),
        fused_qkv_a_proj=Linear("QKV"), q_lora_rank=1, kv_lora_rank=1, qk_rope_head_dim=1,
        q_a_layernorm=record("q_c_norm", Tensor()),
        indexer_select_pre_process=record("indexer_K", (Tensor(), None)),
        exec_kv=record("attention_KV", (Tensor(), Tensor())),
        _q_proj_and_k_up_proj=record("attention_Q", (Tensor(), Tensor())),
        rope_single=record("attention_Q_rope", Tensor()),
        _get_full_kv=record("full_indexer_K", Tensor()),
        indexer_select_post_process=record("LightningIndexer", Tensor()),
        _execute_sparse_flash_attention_process=record("SFA", Tensor()),
        _v_up_proj=record("V_up", Tensor()), o_proj=Linear("O"),
        _record_dcp_kv_gather_context=record("kv_context"),
        _record_dcp_query_gather_context=record("q_context"),
    )
    impl.__dict__.update(overrides)
    md = NS(attn_state=state, cos=Tensor(), sin=Tensor(), slot_mapping=Tensor(),
            cum_query_lens=Tensor(), seq_lens=Tensor(), num_input_tokens=4, dcp_context=None)
    scope = dict(
        _SFA_DEFER_ATTN_PREP=enabled, _sfa_reorder_os=os,
        AscendAttentionState=NS(DecodeOnly="decode", SpecDecoding="spec"),
        AscendDeviceType=NS(A5="A5"), get_ascend_device_type=lambda: "910C",
        torch_npu=NS(npu_scatter_nd_update_=record("indexer_cache_write")),
        get_weight_prefetch_method=lambda: NS(maybe_prefetch_mla_or_sla_weight_in_current_stream=record("weight_prefetch")),
        wait_for_kv_layer_from_connector=record("connector_wait"),
        maybe_save_kv_layer_to_connector=record("connector_save"),
        get_ascend_config=lambda: NS(c8_enable_reshape_optim=False),
        MLAPO_MAX_SUPPORTED_TOKENS=16, MAX_O_PROJ_PREFETCH_SIZE=1,
    )
    tree = ast.parse(source)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "AscendSFAImpl")
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "forward")
    fn.returns = None
    for arg in fn.args.args: arg.annotation = None
    exec(compile(ast.Module(body=[fn], type_ignores=[]), "<forward-control-flow>", "exec"), scope)
    scope["forward"](impl, "layer", Tensor(), (Tensor(), Tensor(), Tensor()), md, output=Tensor())
    return calls


if __name__ == "__main__":
    root = Path(__file__).resolve().parent.parent
    sources = [
        root / "dsv32_profiler_full_b8_16k_2026-10-13/source_snapshot/sfa_v1.py",
        root / "sfa-dual-910c-v023/sfa_v1.upstream.py",
    ]
    for path in sources:
        original = path.read_text()
        patched = transform(original)
        for state in ("decode", "prefill", "spec"):
            assert run(original, False, state) == run(patched, False, state)
        for state in ("prefill", "spec"):
            assert run(original, False, state) == run(patched, True, state)
        calls = run(patched, True)
        expected = ["QKV", "q_c_norm", "indexer_K", "indexer_cache_write",
                    "LightningIndexer", "attention_KV", "attention_Q", "attention_Q_rope", "SFA", "V_up", "O"]
        assert [x for x in calls if x in expected] == expected, calls
        for bad in ({"enable_mlapo": True}, {"enable_dsa_cp": True},
                    {"vllm_config": NS(kv_transfer_config=object())}, {"is_kv_producer": True},
                    {"enable_sparse_sfa_c8": True}, {"skip_topk": True}):
            try:
                run(patched, True, **bad)
            except RuntimeError as exc:
                assert "does not support" in str(exc)
            else:
                raise AssertionError(f"Missing guard: {bad}")
        print(f"PASS: {path.name}: baseline/prefill/spec preserved; reordered decode; unsupported modes rejected")
    try:
        transform(sources[0].read_text() + "\n")
    except ValueError:
        print("PASS: unknown source rejected")
    else:
        raise AssertionError("Unknown source accepted")
