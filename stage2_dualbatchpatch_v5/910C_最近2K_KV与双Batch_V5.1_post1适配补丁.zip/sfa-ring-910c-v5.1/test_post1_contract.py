"""Run official KV spec/registry class bodies on CPU, without importing CANN.

Only platform discovery and ancillary dependencies are supplied locally. The
spec dataclasses, merge, size, and registry lookup methods are official source.
This is not an end-to-end vLLM engine or NPU test.
"""
import ast
import copy
from dataclasses import dataclass, field, fields, replace
from enum import Enum, IntEnum
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace as NS
import unittest

import torch

ROOT = Path(__file__).resolve().parent


def execute_definitions(path, names, env):
    tree = ast.parse(path.read_text())
    nodes = [n for n in tree.body if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in names]
    assert {n.name for n in nodes} == set(names)
    future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future, *nodes], type_ignores=[]))
    exec(compile(module, str(path), 'exec'), env)


def load_contract():
    module = ModuleType('post1_source_contract')
    sys.modules[module.__name__] = module
    env = module.__dict__
    env.update(dataclass=dataclass, field=field, fields=fields, replace=replace,
               Enum=Enum, IntEnum=IntEnum, torch=torch, copy=copy,
               cdiv=lambda a,b: (a+b-1)//b,
               round_up=lambda a,b: ((a+b-1)//b)*b,
               get_dtype_size=lambda dtype: torch.empty((),dtype=dtype).element_size(),
               _REGISTRY_KVCACHESPEC_LIST={})
    ref=ROOT/'reference'/'post1'
    execute_definitions(ref/'kv_cache_spec_registry.py',
                        ['KVCacheSpecMetadata','KVCacheSpecRegistry'],env)
    execute_definitions(ref/'vllm_kv_cache_interface.py',
                        ['KVQuantMode','KVCacheSpec','AttentionSpec','FullAttentionSpec',
                         'MLAAttentionSpec','_apply_alignment_padding'],env)
    # Hardware detection is the sole platform-specific dependency of the
    # Ascend spec's default dtype factories. Use the audited A3 path.
    env.update(AscendDeviceType=NS(A5='A5'),get_ascend_device_type=lambda:'A3')
    execute_definitions(ref/'ascend_kv_cache_interface.py',
                        ['_get_c8_k_cache_dtype','_get_c8_k_scale_cache_dtype','AscendMLAAttentionSpec'],env)
    execute_definitions(ROOT/'sfa_ring_spec.py',['RingIndexerSpec'],env)
    return NS(**env)


class Post1ContractTests(unittest.TestCase):
    def setUp(self):
        self.contract=load_contract()
        self.spec=self.contract.RingIndexerSpec(block_size=128,num_kv_heads=1,
                   head_size=704,dtype=torch.bfloat16,sparse_head_dim=(512,64,128))

    def test_official_merge_keeps_subclass_and_indexer_page_budget(self):
        c=self.contract
        merged=self.spec.merge([self.spec,copy.deepcopy(self.spec)])
        self.assertIsInstance(merged,c.RingIndexerSpec)
        self.assertEqual(merged.page_size_bytes,128*128*2)
        self.assertEqual(merged.real_page_size_bytes,128*128*2)
        config=NS(model_config=NS(max_model_len=65600),
                  parallel_config=NS(decode_context_parallel_size=1,prefill_context_parallel_size=1))
        self.assertEqual(merged.max_memory_usage_bytes(config),513*128*128*2)
        self.assertEqual(merged.sparse_head_dim,(512,64,128))
        self.assertIsInstance(merged.copy_with_new_block_size(128),c.RingIndexerSpec)
        copied=c.RingIndexerSpec(**{f.name:getattr(merged,f.name) for f in fields(merged) if f.init})
        self.assertEqual(copied,merged)

    def test_official_registry_resolves_parent_manager_for_ring_spec(self):
        c=self.contract
        class CompressAttentionManager:pass
        c.KVCacheSpecRegistry.register(c.AscendMLAAttentionSpec,
               CompressAttentionManager,c.FullAttentionSpec)
        c.KVCacheSpecRegistry.check_kv_cache_spec_registry({'layer0':self.spec})
        self.assertIs(c.KVCacheSpecRegistry.get_manager_class(self.spec),CompressAttentionManager)
        self.assertIs(c.KVCacheSpecRegistry.get_uniform_type_base_spec(self.spec),c.FullAttentionSpec)


if __name__=='__main__':unittest.main(verbosity=2)
