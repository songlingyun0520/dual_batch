"""CPU execution of real ring planning/mapping/staging code; no NPU claims."""
import ast
import copy
import importlib.util
from pathlib import Path
from types import SimpleNamespace as NS
import unittest

import torch
import sfa_ring_kv as ring

ROOT = Path(__file__).resolve().parent


def values(owner, positions, dim):
    p = torch.as_tensor(positions, dtype=torch.float64)
    cols = [p/1000 + owner*2, torch.sin(p/37)+owner]
    return torch.stack(cols[:dim], dim=-1)


def fixture(cap=3, token_capacity=8192):
    rt = ring.RingRuntime.__new__(ring.RingRuntime)
    rt.torch, rt.device = torch, torch.device('cpu')
    rt.capacity, rt.pool, rt.buffers = cap, ring.SlotPool(cap), {}
    rt.info = dict(token_capacity=token_capacity)
    blocks = (cap+1)*16+ring.ceildiv(token_capacity,128)+cap
    rt.stage = (torch.zeros((blocks,128,1,2),dtype=torch.float64),
                torch.zeros((blocks,128,1,1),dtype=torch.float64))
    caches = (torch.zeros(((cap+1)*16,128,1,2),dtype=torch.float64),
              torch.zeros(((cap+1)*16,128,1,1),dtype=torch.float64),
              torch.randn((100,128,1,2),dtype=torch.float64))
    rt.caches = {'layer':caches}
    return rt, caches


def metadata(rt, ids, begins, chunks, decode=False, padding=0, dummy=False, key='layer'):
    starts = [0]
    for c in chunks: starts.append(starts[-1]+c)
    for req in ids:
        rt.pool.acquire(req)
    md = NS(seq_lens=torch.tensor([b+c for b,c in zip(begins,chunks)],dtype=torch.int32),
            seq_lens_cpu=torch.tensor([b+c for b,c in zip(begins,chunks)],dtype=torch.int32),
            block_table=torch.zeros((len(ids),100),dtype=torch.int32),
            slot_mapping=torch.arange(starts[-1]+padding),
            num_input_tokens=starts[-1]+padding,num_actual_tokens=starts[-1],
            attn_state=NS(name='DecodeOnly' if decode else 'ChunkedPrefill'),
            cum_query_lens=torch.tensor(starts[1:],dtype=torch.int32))
    runner = NS(query_start_loc=NS(cpu=torch.tensor(starts)),input_batch=NS(req_ids=ids))
    ring.prepare_metadata(rt,runner,md,key,dummy)
    return md


def native_sfa(impl, q, qr, caches, indices, md, qlens, klens):
    """Paged attention oracle with the native per-request causal offset."""
    out = torch.zeros_like(q)
    lo = 0
    for req, hi in enumerate(qlens.tolist()):
        qcount = hi-lo
        for t in range(lo,hi):
            ix = indices[t].reshape(-1)
            ix = ix[ix>=0].long()
            if len(ix):
                allowed = int(klens[req])-qcount+(t-lo)+1
                assert int(ix.max()) < allowed, (int(ix.max()), allowed)
                physical = md.block_table[req,ix//128].long()*128+ix%128
                kv = caches[0].view(-1,2)[physical]
                weights = torch.softmax((kv*q[t]).sum(-1),dim=0)
                out[t] = (weights[:,None]*kv).sum(0)
        lo = hi
    return out


class RingTests(unittest.TestCase):
    def setUp(self):
        self.old_enabled = ring.ENABLED
        ring.ENABLED = True

    def tearDown(self):
        ring.ENABLED = self.old_enabled

    def test_mapping_window_and_invalid_entries(self):
        for end in (0,1,17,2047,2048,2049,4096,16433):
            idx = torch.tensor([[-3,-1,0,max(0,end-2049),max(0,end-2048),max(0,end-1),end,end+1]],dtype=torch.int32)
            base = max(0,end-2500)
            mapped = ring.map_indices(idx,torch.tensor([end]),torch.tensor([base]))
            physical = ring.map_indices(idx,torch.tensor([end]))
            for j,v in enumerate(idx[0].tolist()):
                if not 0<=v<end:
                    self.assertEqual(int(mapped[0,j]),-1)
                    self.assertEqual(int(physical[0,j]),-1)
                else:
                    start=max(0,end-2048)
                    expected=start+(v-start)%min(end,2048)
                    self.assertEqual(int(mapped[0,j]),expected-base)
                    self.assertEqual(int(physical[0,j]),expected%2048)
                    self.assertTrue(start<=expected<end)

    def test_prefill_wrap_mixed_chunks_then_decode(self):
        rt,caches=fixture()
        ids=['b','a']; begins=[0,0]
        index_before=caches[2].clone()
        for chunks in ([1024,65],[4097,2500],[3,1],[1,1]):
            decode=chunks==[1,1]
            md=metadata(rt,ids,begins,chunks,decode=decode,padding=3)
            ring_tables=md.block_table.clone(); ring_lens=md.seq_lens.clone()
            dest,slots=ring.prepare_kv(md,caches)
            n=md.num_input_tokens
            q=torch.full((n,2),.07,dtype=torch.float64)
            ix=torch.full((n,1,7),-1,dtype=torch.int32)
            expected=torch.zeros_like(q)
            lo=0
            for owner,(req,begin,count) in enumerate(zip(ids,begins,chunks)):
                pos=list(range(begin,begin+count))
                for target,dim in zip(dest[:2],(2,1)):
                    target.view(-1,dim).index_copy_(0,slots[lo:lo+count],values(owner,pos,dim))
                for t,position in enumerate(pos,lo):
                    end=position+1
                    chosen=[0,max(0,position-2048),max(0,position-2047),position,-1,end,position]
                    ix[t,0]=torch.tensor(chosen)
                    selected=[v for v in chosen if 0<=v<end]
                    start=max(0,end-2048)
                    mapped=[start+(v-start)%min(end,2048) for v in selected]
                    kv=values(owner,mapped,2)
                    weights=torch.softmax((kv*q[t]).sum(-1),dim=0)
                    expected[t]=(weights[:,None]*kv).sum(0)
                lo+=count
            original_indices=ix.clone()
            out=ring.attend(native_sfa,None,q,q,caches,ix,md,md.cum_query_lens,md.seq_lens)
            torch.testing.assert_close(out,expected)
            torch.testing.assert_close(md.block_table,ring_tables)
            torch.testing.assert_close(md.seq_lens,ring_lens)
            torch.testing.assert_close(ix,original_indices)
            torch.testing.assert_close(caches[2],index_before)
            for owner,(req,begin,count) in enumerate(zip(ids,begins,chunks)):
                end=begin+count; positions=torch.arange(max(0,end-2048),end)
                addresses=rt.pool.owners[req]*2048+positions%2048
                torch.testing.assert_close(caches[0].view(-1,2)[addresses],values(owner,positions,2))
            begins=[b+c for b,c in zip(begins,chunks)]

    def test_decode_split_matches_unsplit_after_wrap_and_padding(self):
        rt,caches=fixture(cap=5)
        ids=['c','a','e','b','d']; lengths=[2048,2049,8000,31,16384]
        md=metadata(rt,ids,[e-1 for e in lengths],[1]*5,decode=True)
        for owner,(req,end) in enumerate(zip(ids,lengths)):
            positions=torch.arange(max(0,end-2048),end)
            addr=rt.pool.owners[req]*2048+positions%2048
            caches[0].view(-1,2).index_copy_(0,addr,values(owner,positions,2))
        q=torch.randn((5,2),dtype=torch.float64)
        ix=torch.tensor([[[0,10,e-1,-1]] for e in lengths],dtype=torch.int32)
        full=ring.attend(native_sfa,None,q,q,caches,ix,md,md.cum_query_lens,md.seq_lens)
        pieces=[]
        for lo,hi in ((0,3),(3,5)):
            child=copy.copy(md);child.cum_query_lens=md.cum_query_lens[lo:hi]-lo
            ring.slice_metadata(md,child,lo,hi)
            pieces.append(ring.attend(native_sfa,None,q[lo:hi],q[lo:hi],caches,ix[lo:hi],child,child.cum_query_lens,child.seq_lens))
        torch.testing.assert_close(full,torch.cat(pieces))

    def test_fixed_metadata_addresses_change_values_and_reorder_requests(self):
        rt,_=fixture()
        a=metadata(rt,['x','y'],[2047,2048],[1,1],decode=True)
        ptrs={k:a._ring[k].data_ptr() for k in ('slots','horizons','table','lengths')}
        b=metadata(rt,['y','x'],[2049,2048],[1,1],decode=True)
        self.assertEqual(ptrs,{k:b._ring[k].data_ptr() for k in ptrs})
        self.assertEqual(b._ring['horizons'].tolist(),[2050,2049])
        self.assertEqual(b._ring['slots'].tolist(),[2049,0])

    def test_dummy_and_compact_padding_do_not_write_live_slots(self):
        rt,caches=fixture()
        md=metadata(rt,['real'],[4000],[1],decode=True,padding=112)
        self.assertEqual(md._ring['slots'][1:].tolist(),[-1]*112)
        self.assertEqual(md._ring['horizons'][1:].tolist(),[0]*112)
        dummy=metadata(rt,['real'],[0],[1],decode=True,dummy=True,key='dummy')
        self.assertEqual(dummy._ring['slots'].tolist(),[-1])
        self.assertEqual(int(dummy._ring['table'][0,0]),rt.capacity*16)
        self.assertEqual(dummy._ring['horizons'].tolist(),[0])

    def test_metadata_storage_is_bounded_across_changing_prefill_sizes(self):
        rt,_=fixture()
        pointers=[]
        for q in (1,2,13,256,4096,17,8):
            md=metadata(rt,['a'],[0],[q],decode=False)
            pointers.append(md._ring['slots'].data_ptr())
        self.assertEqual(len(rt.buffers),5)
        self.assertEqual(len(set(pointers)),1)

    def test_slot_recycle_and_recompute_guard(self):
        p=ring.SlotPool(2)
        self.assertEqual(p.acquire('a'),(0,True));self.assertEqual(p.acquire('b'),(1,True))
        p.advance('a',0,100)
        with self.assertRaisesRegex(RuntimeError,'missing/reused'):
            p.advance('a',99,105)
        with self.assertRaisesRegex(RuntimeError,'no free'):
            p.acquire('c')
        p.release('a');self.assertEqual(p.acquire('c'),(0,True));p.advance('c',0,8)
        p.advance('c',0,3)  # preemption recompute restarts at zero

    def test_workspace_bound(self):
        cap=64; tokens=4096
        chunks=[1]*63+[tokens-63]
        starts=[0]
        for q in chunks:starts.append(starts[-1]+q)
        _,used=ring.make_plan(list(range(cap)),starts,[16000+q for q in chunks],tokens)
        blocks=(cap+1)*16+ring.ceildiv(tokens,128)+cap
        self.assertLessEqual(used,blocks*128-2048) # dedicated dummy pages untouched

    def test_forward_hooks_present_and_original_indexer_calls_retained(self):
        tree=ast.parse((ROOT/'sfa_v1.py').read_text())
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='AscendSFAImpl')
        methods={n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)}
        for name,hook in [('exec_kv','prepare_kv'),('_execute_sparse_flash_attention_process','attend'),('forward','validate_impl')]:
            self.assertTrue(any(isinstance(n,ast.Attribute) and n.attr==hook for n in ast.walk(methods[name])))
        # Ring mapping is applied in SFA only; no replacement of Indexer top-k.
        self.assertNotIn('map_indices',ast.unparse(methods['forward']))


if __name__=='__main__':
    unittest.main(verbosity=2)
