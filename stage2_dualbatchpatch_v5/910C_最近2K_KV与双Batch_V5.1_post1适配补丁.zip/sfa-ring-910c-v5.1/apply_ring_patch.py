#!/usr/bin/env python3
"""Install V5.1 ring KV (including audited v0.23.0.post1). Default dry run."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile

HERE = Path(__file__).resolve().parent
MARKER = '# SFA_RING_KV_V5_RUNTIME_HOOK'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def atomic(path, data, mode=0o644):
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.ring-v5-', delete=False) as f:
            tmp = Path(f.name)
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        tmp.chmod(mode)
        os.replace(tmp, path)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)


def changes(root):
    manifest = json.loads((HERE/'package_manifest.json').read_text())
    output = {}
    for name, checksum in manifest['payload'].items():
        data = (HERE/name).read_bytes()
        if sha(data) != checksum:
            raise SystemExit(f'Packaged checksum mismatch: {name}; unchanged.')
        compile(data, name, 'exec')
        output[root/'attention'/name] = data
    sfa = root/'attention'/'sfa_v1.py'
    if sha(sfa.read_bytes()) not in manifest['accepted_sfa'] + [sha(output[sfa])]:
        raise SystemExit('Unsupported installed sfa_v1.py; provide its exact source before adapting.')
    runner = root/'worker'/'model_runner_v1.py'
    text = runner.read_text()
    hook = f'\n\n{MARKER}\nfrom vllm_ascend.attention.sfa_ring_kv import install_runner as _install_ring_v5\n_install_ring_v5(NPUModelRunner)\n'
    original = text[:-len(hook)] if text.endswith(hook) else text
    runner_sha = sha(original.encode())
    audited_runners = manifest['audited_runners']
    if runner_sha not in audited_runners:
        raise SystemExit(
            f'Unsupported model_runner_v1.py checksum; no files changed.\n'
            f'Path: {runner}\nActual SHA256: {runner_sha}\n'
            f'Audited SHA256 values: {", ".join(audited_runners)}\n'
            'V5.1 includes official v0.23.0.post1; a derived image may differ. '
            'Do not bypass this check. Preserve the exact source for comparison.'
        )
    print(f'Recognized runner: {audited_runners[runner_sha]} ({runner_sha})')
    output[runner] = (original+hook).encode()
    worker = root/'worker'/'worker.py'
    text = worker.read_text()
    installed_worker_text = text
    if MARKER in text:
        text = text[:text.index('\n\n'+MARKER)]
    tree = ast.parse(text)
    candidates = [node.name for node in tree.body if isinstance(node, ast.ClassDef)
                  and any(isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))
                          and f.name == 'determine_available_memory' for f in node.body)]
    if len(candidates) != 1:
        raise SystemExit('Cannot identify a unique worker.determine_available_memory; unchanged.')
    # Worker hook is an append-only decorator. Its return is validated at runtime;
    # no unknown worker method body is replaced.
    worker_hook = f'\n\n{MARKER}\nfrom vllm_ascend.attention.sfa_ring_kv import install_worker as _install_ring_worker_v5\n_install_ring_worker_v5({candidates[0]})\n'
    if MARKER in installed_worker_text and installed_worker_text != text+worker_hook:
        raise SystemExit('Worker V5 hook was edited; refusing to discard its changes.')
    output[worker] = (text+worker_hook).encode()
    for path, data in output.items():
        compile(data, str(path), 'exec')
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, help='vllm_ascend package directory')
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--restore', action='store_true', help='restore exact pre-install files; combine with --apply')
    args = parser.parse_args()
    if args.root:
        root = args.root.resolve()
    else:
        spec = importlib.util.find_spec('vllm_ascend')
        if spec is None or not spec.submodule_search_locations:
            raise SystemExit('Cannot locate vllm_ascend; use service Python or --root.')
        root = Path(next(iter(spec.submodule_search_locations))).resolve()
    record_path = root/'sfa_ring_v5_install.json'
    if args.restore:
        record = json.loads(record_path.read_text())
        for item in record:
            target = root/item['relative']
            if not target.exists() or sha(target.read_bytes()) != item['new_sha256']:
                raise SystemExit(f'Installed file changed after V5: {target}; refusing overwrite.')
            if item['existed']:
                data = Path(item['backup']).read_bytes()
                if sha(data) != item['old_sha256']:
                    raise SystemExit('Backup checksum mismatch; unchanged.')
        if args.apply:
            for item in record:
                target = root/item['relative']
                if item['existed']:
                    atomic(target, Path(item['backup']).read_bytes(), item['mode'])
                else:
                    target.unlink()
            record_path.unlink()
        print('Restored pre-V5 files.' if args.apply else 'Restore dry run passed; no files changed.')
        return
    payload = changes(root)
    record = []
    for path, data in payload.items():
        existed = path.exists()
        old = path.read_bytes() if existed else b''
        print(f'{path}: {sha(old) if existed else "new file"} -> {sha(data)}')
        record.append(dict(relative=str(path.relative_to(root)), existed=existed,
                           old_sha256=sha(old), new_sha256=sha(data),
                           backup=str(path)+'.before_ring_v5',
                           mode=stat.S_IMODE(path.stat().st_mode) if existed else 0o644))
    if all((root/x['relative']).exists() and sha((root/x['relative']).read_bytes()) == x['new_sha256'] for x in record):
        print('V5 already installed; unchanged.')
        return
    if record_path.exists():
        raise SystemExit('Existing V5 install record; restore first rather than overwrite backups.')
    if not args.apply:
        print('Dry run passed; no files changed. Stop ALL workers, rerun with --apply, then restart/recapture.')
        return
    for x in record:
        if x['existed'] and Path(x['backup']).exists():
            raise SystemExit('Backup already exists; refusing overwrite: '+x['backup'])
    originals = {p: p.read_bytes() if p.exists() else None for p in payload}
    written = []
    try:
        for x in record:
            p = root/x['relative']
            if x['existed']:
                with Path(x['backup']).open('xb') as f:
                    f.write(originals[p])
        for x in record:
            p = root/x['relative']
            atomic(p, payload[p], x['mode'])
            written.append(p)
        atomic(record_path, json.dumps(record, indent=2).encode())
    except BaseException:
        for p in reversed(written):
            old = originals[p]
            if old is None:
                p.unlink(missing_ok=True)
            else:
                atomic(p, old)
        raise
    print('Installed experimental V5. Set VLLM_ASCEND_SFA_RING_KV=1 and restart all workers.')
    print('Keep enable_mlapo=false. VLLM_ASCEND_SFA_DUAL_BATCH=0/1 remains available.')
    print('CPU validation does not establish target 910C NPU/graph compatibility.')


if __name__ == '__main__':
    main()
