"""V5 experimental recent-2K attention KV; full-history native Indexer.

This deliberately changes attention semantics. An evicted index maps to the
latest causal token with the same residue modulo 2048. Duplicates are retained.
No model weights, Indexer keys/scores/top-k implementation or TP/EP ops change.
"""
from __future__ import annotations

import copy
import functools
import inspect
import os
from dataclasses import dataclass, fields

WINDOW = 2048
BLOCK = 128
_setting = os.environ.get("VLLM_ASCEND_SFA_RING_KV", "0")
if _setting not in {"0", "1"}:
    raise ValueError("VLLM_ASCEND_SFA_RING_KV must be 0 or 1")
ENABLED = _setting == "1"


def ceildiv(x, y):
    return (x + y - 1) // y


@dataclass
class RequestPlan:
    slot: int
    lo: int
    hi: int
    begin: int
    end: int
    old_begin: int
    stage_offset: int

    @property
    def stage_length(self):
        return self.end - self.old_begin


def make_plan(slots, starts, lengths, actual_tokens, window=WINDOW, block=BLOCK):
    """CPU-only metadata planning. No tensor values read during graph replay."""
    if len(starts) != len(lengths) + 1 or len(slots) != len(lengths):
        raise ValueError("ring request metadata lengths disagree")
    if starts[0] != 0 or any(a > b for a, b in zip(starts, starts[1:])):
        raise ValueError("invalid cumulative query offsets")
    plans = []
    offset = 0
    for i, (slot, end) in enumerate(zip(slots, lengths)):
        lo, hi = min(starts[i], actual_tokens), min(starts[i+1], actual_tokens)
        if slot < 0 or hi == lo:
            continue
        begin = end - (hi - lo)
        if begin < 0:
            raise ValueError("query count exceeds sequence length")
        p = RequestPlan(slot, lo, hi, begin, end, max(0, begin-window), offset)
        plans.append(p)
        offset += ceildiv(p.stage_length, block) * block
    return plans, offset


def map_indices(indices, horizons, bases=None, window=WINDOW):
    """Map to physical ring residues (decode) or chronological staging (prefill).

    -1 and other invalid/future original indices remain invalid. Per-query
    horizons prevent later tokens in a prefill chunk becoming visible early.
    """
    import torch
    h = horizons.reshape((-1,) + (1,) * (indices.ndim-1))
    valid = (indices >= 0) & (indices < h)
    if bases is None:
        mapped = indices.remainder(window)
    else:
        start = (h-window).clamp(min=0)
        width = h.clamp(min=1, max=window)
        absolute = start + (indices-start).remainder(width)
        base = bases.reshape((-1,) + (1,) * (indices.ndim-1))
        mapped = absolute-base
    return torch.where(valid, mapped, -1).to(indices.dtype)


class SlotPool:
    def __init__(self, capacity):
        self.capacity = capacity
        self.owners = {}
        self.ends = {}

    def release(self, req):
        self.ends.pop(req, None)
        return self.owners.pop(req, None)

    def acquire(self, req):
        if req in self.owners:
            return self.owners[req], False
        free = sorted(set(range(self.capacity)) - set(self.owners.values()))
        if not free:
            raise RuntimeError("ring KV has no free request slot; check preemption lifecycle")
        self.owners[req] = free[0]
        self.ends[req] = 0
        return free[0], True

    def advance(self, req, begin, end):
        previous = self.ends.get(req, 0)
        if begin != previous and begin != 0:
            raise RuntimeError(f"ring KV missing/reused history for {req!r}: stored={previous}, begin={begin}")
        self.ends[req] = end


def validate_config(config):
    p = config.parallel_config
    failures = []
    for key in ("pipeline_parallel_size", "decode_context_parallel_size", "prefill_context_parallel_size"):
        if getattr(p, key, 1) != 1:
            failures.append(key)
    if config.kv_transfer_config is not None:
        failures.append("KV connector")
    if config.speculative_config is not None:
        failures.append("speculative decoding/MTP")
    if config.cache_config.enable_prefix_caching:
        failures.append("prefix caching")
    if getattr(config, "lora_config", None) is not None:
        failures.append("LoRA")
    if config.compilation_config.cudagraph_mode.name not in {"NONE", "FULL_DECODE_ONLY"}:
        failures.append("graph mode other than NONE/FULL_DECODE_ONLY")
    if failures:
        raise RuntimeError("SFA ring KV unsupported: " + ", ".join(failures))


def validate_impl(impl, md):
    if not ENABLED:
        return
    validate_config(impl.vllm_config)
    flags = ("enable_mlapo", "enable_dsa_cp", "enable_sfa_prolog_v3", "enable_sparse_sfa_c8",
             "enable_sparse_li_c8", "use_sparse_c8_indexer", "skip_topk", "use_index_cache", "is_kv_producer")
    bad = [name for name in flags if getattr(impl, name, False)]
    if not getattr(impl, "has_indexer", False):
        bad.append("missing Indexer")
    if bad:
        raise RuntimeError("SFA ring KV unsupported: " + ", ".join(bad))
    if md is not None and not hasattr(md, "_ring"):
        raise RuntimeError("ring metadata absent; install BOTH runner and attention patches")


def _specs(runner):
    import torch
    specs = runner._ring_original_get_spec()
    validate_config(runner.vllm_config)
    if not specs or not runner.use_sparse or getattr(runner, "shared_kv_cache_layers", {}):
        raise RuntimeError("ring KV requires unshared DeepSeek V3.2 sparse attention layers")
    for name, spec in specs.items():
        if (tuple(getattr(spec, "sparse_head_dim", ())) != (512, 64, 128)
                or spec.block_size != BLOCK or spec.num_kv_heads != 1
                or spec.dtype not in (torch.bfloat16, torch.float16)
                or getattr(spec, "cache_sparse_sfa_c8", False)
                or getattr(spec, "cache_sparse_li_c8", False)
                or getattr(spec, "sfa_dcp_replicated_indexer_size", 1) != 1
                or getattr(spec, "page_size_padded", None) is not None):
            raise RuntimeError(f"unsupported ring KV cache spec: {name}: {spec}")
    if len({s.dtype for s in specs.values()}) != 1:
        raise RuntimeError("ring workspace requires homogeneous KV dtype")
    return specs


def budget(runner):
    import torch
    specs = _specs(runner)
    cap = runner.scheduler_config.max_num_seqs
    tokens = max(runner.scheduler_config.max_num_batched_tokens, cap,
                 runner.vllm_config.compilation_config.max_cudagraph_capture_size or 0)
    # One dedicated zero dummy slot; never write graph padding into a live slot.
    attn = sum((cap+1)*WINDOW*576*torch.empty((), dtype=s.dtype).element_size() for s in specs.values())
    # Shared across layers: old recent history plus the current chunk, with page alignment.
    workspace_blocks = (cap+1)*ceildiv(WINDOW, BLOCK) + ceildiv(tokens, BLOCK) + cap
    workspace = workspace_blocks*BLOCK*576*2
    # Upper bound for mappings, captured metadata, per-request copy temporaries.
    extra = 64*1024**2 + len(specs)*(tokens*32 + (cap+1)*(ceildiv(WINDOW+tokens, BLOCK)*4+128))
    return dict(attention_bytes=attn, workspace_bytes=workspace, metadata_margin_bytes=extra,
                reserved_bytes=attn+workspace+extra, workspace_blocks=workspace_blocks,
                capacity=cap, token_capacity=tokens, layer_count=len(specs))


class RingRuntime:
    def __init__(self, runner, specs, config):
        import torch
        self.torch = torch
        self.device = runner.device
        self.info = budget(runner)
        self.capacity = self.info["capacity"]
        self.pool = SlotPool(self.capacity)
        self.caches = {}
        self.buffers = {}
        self.dtype = next(iter(specs.values())).dtype
        for name, spec in specs.items():
            self.caches[name] = (
                torch.zeros(((self.capacity+1)*16, BLOCK, 1, 512), dtype=spec.dtype, device=self.device),
                torch.zeros(((self.capacity+1)*16, BLOCK, 1, 64), dtype=spec.dtype, device=self.device),
                torch.zeros((config.num_blocks, BLOCK, 1, 128), dtype=spec.dtype, device=self.device),
            )
        self.stage = tuple(torch.zeros((self.info['workspace_blocks'], BLOCK, 1, d),
                                      dtype=self.dtype, device=self.device) for d in (512, 64))
        self.info["indexer_bytes"] = sum(c[2].numel()*c[2].element_size() for c in self.caches.values())
        self.info["logical_indexer_blocks"] = config.num_blocks
        print("SFA_RING_KV_ALLOCATION " + __import__('json').dumps(self.info), flush=True)

    def clear_slot(self, slot):
        for caches in self.caches.values():
            for cache in caches[:2]:
                cache[slot*16:(slot+1)*16].zero_()

    def buffer(self, key, value, dtype, capacity_shape):
        torch = self.torch
        # A private pinned source is necessary: nonblocking copies cannot reuse
        # a host array that is mutated before the DMA completes.
        host = torch.tensor(value, dtype=dtype)
        if self.device.type != "cpu":
            host = host.pin_memory()
        fullkey = key, dtype
        if fullkey not in self.buffers:
            self.buffers[fullkey] = torch.empty(capacity_shape, dtype=dtype, device=self.device)
        storage = self.buffers[fullkey]
        if tuple(storage.shape) != tuple(capacity_shape) or any(a>b for a,b in zip(host.shape, storage.shape)):
            raise RuntimeError("ring fixed metadata capacity mismatch")
        out = storage[tuple(slice(0,n) for n in host.shape)]
        out.copy_(host, non_blocking=True)
        return out


def prepare_metadata(runtime, runner, md, key, dummy):
    import torch
    rows = md.seq_lens.shape[0]
    capacity = md.num_input_tokens
    actual = md.num_actual_tokens
    starts = runner.query_start_loc.cpu[:rows+1].tolist()
    lengths = md.seq_lens_cpu.tolist() if md.seq_lens_cpu is not None else None
    if lengths is None:
        raise RuntimeError("ring KV needs CPU sequence lengths; async speculative decoding unsupported")
    ids = list(runner.input_batch.req_ids)
    slots = [-1]*rows
    for i in range(min(len(ids), rows)):
        if not dummy and ids[i] is not None and starts[i] < actual:
            if ids[i] not in runtime.pool.owners:
                raise RuntimeError("request slot not registered by runner update hook")
            slots[i] = runtime.pool.owners[ids[i]]
    if rows > runtime.capacity or capacity > runtime.info["token_capacity"]:
        raise RuntimeError("ring metadata exceeds configured request/token capacity")
    plans, used = make_plan(slots, starts, lengths, actual)
    if used > runtime.stage[0].shape[0]*BLOCK:
        raise RuntimeError("ring prefill staging capacity exceeded")
    decode = md.attn_state.name == "DecodeOnly"
    if decode and any(p.hi-p.lo != 1 for p in plans):
        raise RuntimeError("DecodeOnly has multiple tokens per real request")
    positions = [-1]*capacity
    horizons = [0]*capacity
    bases = [0]*capacity
    write_slots = [-1]*capacity
    widths = 16 if decode else ceildiv(WINDOW+runtime.info["token_capacity"], BLOCK)
    # All dummy rows read a dedicated zero region, never another request's KV.
    dummy_base = runtime.capacity*16 if decode else runtime.stage[0].shape[0]-16
    tables = [[dummy_base+j if j < 16 else dummy_base for j in range(widths)] for _ in range(rows)]
    lens = [1]*rows
    by_lo = {p.lo:p for p in plans}
    for i, slot in enumerate(slots):
        p = by_lo.get(starts[i]) if slot >= 0 else None
        if p is None:
            continue
        for t, pos in zip(range(p.lo, p.hi), range(p.begin, p.end)):
            positions[t], horizons[t], bases[t] = pos, pos+1, p.old_begin
            write_slots[t] = slot*WINDOW+pos % WINDOW if decode else p.stage_offset+(pos-p.old_begin)
        count = 16 if decode else ceildiv(p.stage_length, BLOCK)
        base = slot*16 if decode else p.stage_offset//BLOCK
        tables[i][:count] = list(range(base, base+count))
        lens[i] = min(p.end, WINDOW) if decode else p.stage_length
    if dummy:
        # Capture/dummy compute must not mutate live request storage. Still
        # expose a legal one-key signature for the native SFA tiler.
        pass
    # One bounded set per metadata group/mode, shared across all captured batch
    # sizes. Never retain a new device allocation for every prefill token count.
    host_key = (key, "decode" if decode else "prefill")
    token_shape = (runtime.info['token_capacity'],)
    request_shape = (runtime.capacity,)
    state = dict(runtime=runtime, decode=decode, plans=plans,
                 slots=runtime.buffer((host_key, "slots"), write_slots, torch.int64, token_shape),
                 horizons=runtime.buffer((host_key, "horizons"), horizons, torch.int32, token_shape),
                 bases=runtime.buffer((host_key, "bases"), bases, torch.int32, token_shape),
                 table=runtime.buffer((host_key, "table"), tables, md.block_table.dtype, (runtime.capacity,widths)),
                 lengths=runtime.buffer((host_key, "lengths"), lens, md.seq_lens.dtype, request_shape))
    md._ring = state
    return plans


def slice_metadata(parent, child, lo, hi):
    if not ENABLED:
        return child
    state = dict(parent._ring)
    if not state['decode']:
        raise RuntimeError("ring batch slicing is decode-only")
    for name in ('slots', 'horizons', 'bases', 'table', 'lengths'):
        state[name] = state[name][lo:hi]
    child._ring = state
    return child


def prepare_kv(md, caches):
    """Return only the attention write destination; Indexer keeps original md/cache."""
    state = md._ring
    if state['decode']:
        return caches, state['slots']
    runtime = state['runtime']
    torch = runtime.torch
    # Chronological history + current chunk prevents wraparound overwrite races
    # and keeps the native prefill causal mask consistent with remapped indices.
    for p in state['plans']:
        if p.begin == p.old_begin:
            continue
        src = torch.arange(p.old_begin, p.begin, device=runtime.device).remainder(WINDOW)+p.slot*WINDOW
        for original, stage in zip(caches[:2], runtime.stage):
            flat = original.view(-1, original.shape[-1])
            stage.view(-1, stage.shape[-1])[p.stage_offset:p.stage_offset+len(src)].copy_(flat.index_select(0, src))
    return (*runtime.stage, *caches[2:]), state['slots']


def attend(original, impl, q, qr, caches, indices, md, qlens, klens):
    import torch
    state = md._ring
    mapped = map_indices(indices, state['horizons'], None if state['decode'] else state['bases'])
    compact = copy.copy(md)
    compact.block_table = state['table']
    compact.seq_lens = state['lengths']
    if state['decode']:
        return original(impl, q, qr, caches, mapped, compact, qlens, state['lengths'])
    runtime = state['runtime']
    result = original(impl, q, qr, (*runtime.stage, *caches[2:]), mapped, compact, qlens, state['lengths'])
    # Select the last WINDOW rows once. Never scatter all chunk tokens into
    # modulo slots at once: chunks > WINDOW would have duplicate destinations.
    for p in state['plans']:
        first = max(0, p.end-WINDOW)
        dst = torch.arange(first, p.end, device=runtime.device).remainder(WINDOW)+p.slot*WINDOW
        offset = p.stage_offset+first-p.old_begin
        for cache, stage in zip(caches[:2], runtime.stage):
            source = stage.view(-1, stage.shape[-1])[offset:offset+len(dst)]
            cache.view(-1, cache.shape[-1]).index_copy_(0, dst, source)
    return result


def install_runner(cls):
    if not ENABLED or getattr(cls, '_ring_installed', False):
        return
    for name in ('get_kv_cache_spec', '_allocate_kv_cache_tensors', '_reshape_kv_cache_tensors',
                 '_build_attention_metadata', '_update_states', '_dummy_run', '_zero_block_ids'):
        if not hasattr(cls, name):
            raise RuntimeError(f"unsupported runner: missing {name}")
    cls._ring_installed = True
    original_spec = cls.get_kv_cache_spec
    cls._ring_original_get_spec = original_spec

    def get_spec(self):
        from .sfa_ring_spec import RingIndexerSpec
        specs = _specs(self)
        return {name: RingIndexerSpec(**{f.name:getattr(s, f.name) for f in fields(s) if f.init})
                for name, s in specs.items()}

    def allocate(self, config):
        from .sfa_ring_spec import RingIndexerSpec
        if not getattr(self, '_ring_budget_reserved', False):
            raise RuntimeError("ring memory reservation absent; install the worker hook too")
        allocated_specs = self._get_layer_kv_cache_specs(config)
        if not allocated_specs or not all(isinstance(s, RingIndexerSpec) for s in allocated_specs.values()):
            raise RuntimeError("scheduler did not preserve RingIndexerSpec; refusing inconsistent cache allocation")
        requested = config.num_blocks * sum(s.page_size_bytes for s in allocated_specs.values())
        if requested > self._ring_indexer_budget:
            raise RuntimeError(f"Indexer allocation {requested} exceeds reserved budget {self._ring_indexer_budget}; remove/reduce num-gpu-blocks-override")
        if getattr(self, '_ring_runtime', None) is not None:
            raise RuntimeError("ring cache reinitialization requires a worker restart")
        self._ring_runtime = RingRuntime(self, _specs(self), config)
        return self._ring_runtime.caches

    original_update = cls._update_states
    def update(self, scheduled):
        runtime = getattr(self, '_ring_runtime', None)
        if runtime is not None:
            retired = set(scheduled.finished_req_ids) | set(getattr(scheduled, 'preempted_req_ids', ()) or ())
            for req in retired:
                runtime.pool.release(req)
        result = original_update(self, scheduled)
        if runtime is not None:
            for req in scheduled.num_scheduled_tokens:
                slot, new = runtime.pool.acquire(req)
                if new:
                    runtime.clear_slot(slot)
        return result

    original_dummy = cls._dummy_run
    @functools.wraps(original_dummy)
    def dummy(self, *args, **kwargs):
        self._ring_dummy_depth = getattr(self, '_ring_dummy_depth', 0)+1
        try:
            return original_dummy(self, *args, **kwargs)
        finally:
            self._ring_dummy_depth -= 1

    original_build = cls._build_attention_metadata
    build_sig = inspect.signature(original_build)
    @functools.wraps(original_build)
    def build(self, *args, **kwargs):
        result = original_build(self, *args, **kwargs)
        runtime = getattr(self, '_ring_runtime', None)
        if runtime is None:
            # Profile-run attention normally has metadata=None. Refuse actual
            # ring execution without allocated persistent storage in forward.
            return result
        bound = build_sig.bind(self, *args, **kwargs)
        is_dummy = bool(getattr(self, '_ring_dummy_depth', 0) or bound.arguments.get('for_cudagraph_capture', False))
        mapping = result[0]
        if not isinstance(mapping, dict):
            raise RuntimeError("runner microbatch metadata is not supported by ring V5")
        seen = set()
        first_plans = None
        for name, md in mapping.items():
            if id(md) in seen:
                continue
            seen.add(id(md))
            plans = prepare_metadata(runtime, self, md, name, is_dummy)
            if first_plans is None:
                first_plans = plans
        if not is_dummy and first_plans is not None:
            inverse = {v:k for k, v in runtime.pool.owners.items()}
            for p in first_plans:
                runtime.pool.advance(inverse[p.slot], p.begin, p.end)
        return result

    def zero(self, block_ids):
        import torch
        runtime = self._ring_runtime
        ids = torch.as_tensor(block_ids, dtype=torch.long, device=self.device)
        for caches in runtime.caches.values():
            caches[2].index_fill_(0, ids, 0)

    cls.get_kv_cache_spec = get_spec
    cls._allocate_kv_cache_tensors = allocate
    cls._reshape_kv_cache_tensors = lambda self, config, raw: raw
    cls._update_states = update
    cls._dummy_run = dummy
    cls._build_attention_metadata = build
    cls._init_kv_zero_meta = lambda self: None
    cls._zero_block_ids = zero


def install_worker(cls):
    if not ENABLED or getattr(cls, '_ring_worker_installed', False):
        return
    cls._ring_worker_installed = True
    original = cls.determine_available_memory
    @functools.wraps(original)
    def available(self, *args, **kwargs):
        free = original(self, *args, **kwargs)
        if not isinstance(free, int) or isinstance(free, bool) or free <= 0:
            raise RuntimeError(f"unsupported worker memory-budget return: {free!r}")
        info = budget(self.model_runner)
        remaining = free-info['reserved_bytes']
        if remaining <= 0:
            raise RuntimeError(f"ring KV fixed storage exceeds profiled cache budget: {info}, available={free}")
        print("SFA_RING_KV_BUDGET " + __import__('json').dumps(dict(info, profiled_cache_budget=free,
                                                                  indexer_budget=remaining)), flush=True)
        self.model_runner._ring_budget_reserved = True
        self.model_runner._ring_indexer_budget = remaining
        return remaining
    cls.determine_available_memory = available
