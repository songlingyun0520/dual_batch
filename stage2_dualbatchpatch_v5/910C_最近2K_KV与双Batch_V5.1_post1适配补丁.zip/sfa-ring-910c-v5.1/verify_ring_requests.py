#!/usr/bin/env python3
"""Run one opt-in smoke workload against an ALREADY running target server.

Run separately after starting split=0 and split=1. Saves actual responses and
compares tokens/logprobs when --reference is provided. Does not start profiling.
"""
import argparse
import json
from pathlib import Path
import time
import urllib.request


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base-url',default='http://127.0.0.1:8000')
    p.add_argument('--model',default='deepseek_v3_2')
    p.add_argument('--batch',type=int,default=8)
    p.add_argument('--input-len',type=int,default=16384)
    p.add_argument('--output-len',type=int,default=30)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--reference',type=Path)
    a=p.parse_args()
    if min(a.batch,a.input_len,a.output_len)<=0:raise SystemExit('Lengths and batch must be positive.')
    payload=dict(model=a.model,prompt=[[110+i]*a.input_len for i in range(a.batch)],
                 max_tokens=a.output_len,temperature=0,seed=1024,ignore_eos=True,
                 logprobs=1,stream=False)
    start=time.monotonic()
    request=urllib.request.Request(a.base_url+'/v1/completions',data=json.dumps(payload).encode(),
                                   headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=7200) as response:data=json.load(response)
    choices=sorted(data['choices'],key=lambda x:x['index'])
    if len(choices)!=a.batch:raise RuntimeError('Incomplete response batch')
    for c in choices:
        if len(c['logprobs']['tokens'])!=a.output_len:raise RuntimeError('Unexpected output length')
    result=dict(batch=a.batch,input_len=a.input_len,output_len=a.output_len,
                elapsed_s=time.monotonic()-start,response=data)
    if a.reference:
        ref=json.loads(a.reference.read_text())
        if any(ref[k]!=result[k] for k in ('batch','input_len','output_len')):
            raise RuntimeError('Reference workload differs')
        previous=sorted(ref['response']['choices'],key=lambda x:x['index'])
        result['tokens_match']=all(x['logprobs']['tokens']==y['logprobs']['tokens'] for x,y in zip(choices,previous))
        if result['tokens_match']:
            result['max_logprob_abs_diff']=max(abs(x-y) for c,d in zip(choices,previous)
                for x,y in zip(c['logprobs']['token_logprobs'],d['logprobs']['token_logprobs']))
        else:
            result['max_logprob_abs_diff']=None
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='response'},ensure_ascii=False,indent=2))
    print('This checks request completion/output agreement, not a TPOT measurement or device graph proof.')


if __name__=='__main__':main()
