"""Scheduler pages describe ONLY the full-history Indexer store.

The worker separately reserves and allocates bounded attention storage.
Kept in an importable module because these specs cross process boundaries.
"""
from dataclasses import dataclass

from vllm_ascend.core.kv_cache_interface import AscendMLAAttentionSpec


@dataclass(frozen=True)
class RingIndexerSpec(AscendMLAAttentionSpec):
    @property
    def page_size_bytes(self) -> int:
        import torch
        return self.block_size * self.num_kv_heads * self.sparse_head_dim[2] * torch.empty((), dtype=self.dtype).element_size()

    @property
    def real_page_size_bytes(self) -> int:
        return self.page_size_bytes
