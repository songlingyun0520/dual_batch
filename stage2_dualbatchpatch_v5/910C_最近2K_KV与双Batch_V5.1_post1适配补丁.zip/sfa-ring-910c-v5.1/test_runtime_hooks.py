"""Exercise worker budget and runner hooks using a CPU fake runner contract."""
import importlib
import importlib.util
import pickle
from dataclasses import dataclass
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace as NS
import unittest

import torch
import sfa_ring_kv as ring


@dataclass(frozen=True)
class BaseSpec:
    block_size:int=128
    num_kv_heads:int=1
    head_size:int=704
    sparse_head_dim:tuple=(512,64,128)
    dtype:object=torch.bfloat16
    cache_sparse_sfa_c8:bool=False
    cache_sparse_li_c8:bool=False
    sfa_dcp_replicated_indexer_size:int=1
    page_size_padded:object=None


def setup_spec_module():
    base=ModuleType('vllm_ascend.core.kv_cache_interface');base.AscendMLAAttentionSpec=BaseSpec
    sys.modules[base.__name__]=base
    pkg=ModuleType('ring_cpu_package');pkg.__path__=[str(Path(__file__).resolve().parent)]
    sys.modules[pkg.__name__]=pkg
    ring.__package__=pkg.__name__
    ring.__spec__=importlib.util.spec_from_file_location(pkg.__name__+'.sfa_ring_kv',ring.__file__)


def fake_runner():
    config=NS(parallel_config=NS(pipeline_parallel_size=1,decode_context_parallel_size=1,prefill_context_parallel_size=1),
              kv_transfer_config=None,speculative_config=None,lora_config=None,
              cache_config=NS(enable_prefix_caching=False),
              compilation_config=NS(cudagraph_mode=NS(name='FULL_DECODE_ONLY'),max_cudagraph_capture_size=2))
    class Runner:
        def __init__(self):
            self.vllm_config=config
            self.device=torch.device('cpu')
            self.scheduler_config=NS(max_num_seqs=2,max_num_batched_tokens=128)
            self.use_sparse=True;self.shared_kv_cache_layers={}
            self.input_batch=NS(req_ids=[])
            self.requests={}
        def get_kv_cache_spec(self):return {'model.layers.0.self_attn.attn':BaseSpec()}
        def _get_layer_kv_cache_specs(self,c):return c.specs
        def _allocate_kv_cache_tensors(self,c):raise AssertionError('original allocation used')
        def _reshape_kv_cache_tensors(self,c,r):raise AssertionError('original reshape used')
        def _zero_block_ids(self,ids):raise AssertionError('original zero used')
        def _init_kv_zero_meta(self):raise AssertionError('original zeroer initialized')
        def _dummy_run(self):return self._build_attention_metadata(1,1,1,for_cudagraph_capture=True)
        def _update_states(self,s):
            self.input_batch.req_ids=list(s.num_scheduled_tokens)
            return 'upstream_result'
        def _build_attention_metadata(self,num_tokens,num_reqs,max_query_len,for_cudagraph_capture=False):
            self.query_start_loc=NS(cpu=torch.arange(num_reqs+1))
            md=NS(seq_lens=torch.tensor([getattr(self,'length',1)]*num_reqs,dtype=torch.int32),
                  seq_lens_cpu=torch.tensor([getattr(self,'length',1)]*num_reqs,dtype=torch.int32),
                  block_table=torch.zeros((num_reqs,64),dtype=torch.int32),num_input_tokens=num_tokens,
                  num_actual_tokens=num_reqs,attn_state=NS(name='DecodeOnly'))
            return {'layer0':md,'shared_metadata_alias':md},None
    ring.install_runner(Runner)
    return Runner()


class RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):setup_spec_module()

    def setUp(self):
        self.previous=ring.ENABLED;ring.ENABLED=True

    def tearDown(self):ring.ENABLED=self.previous

    def test_reserve_allocate_request_reorder_preempt_dummy_zero(self):
        runner=fake_runner()
        class Worker:
            model_runner=runner
            def determine_available_memory(self):return 512*1024**2
        ring.install_worker(Worker)
        worker=Worker();available=worker.determine_available_memory()
        self.assertEqual(available,512*1024**2-ring.budget(runner)['reserved_bytes'])
        specs=runner.get_kv_cache_spec()
        restored=pickle.loads(pickle.dumps(specs))
        self.assertEqual(restored,specs)
        self.assertEqual(next(iter(specs.values())).page_size_bytes,128*128*2)
        self.assertEqual(next(iter(specs.values())).sparse_head_dim,(512,64,128))
        conf=NS(specs=specs,num_blocks=12)
        cache=runner._allocate_kv_cache_tensors(conf)
        self.assertIs(runner._reshape_kv_cache_tensors(conf,cache),cache)
        runtime=runner._ring_runtime
        actual_attn=sum(t.numel()*t.element_size() for c in cache.values() for t in c[:2])
        self.assertEqual(actual_attn,ring.budget(runner)['attention_bytes'])
        self.assertEqual(sum(t.numel()*t.element_size() for t in runtime.stage),ring.budget(runner)['workspace_bytes'])
        def update(ids,finished=(),preempted=()):
            return runner._update_states(NS(num_scheduled_tokens=dict.fromkeys(ids,1),finished_req_ids=finished,preempted_req_ids=preempted))
        self.assertEqual(update(['a','b']),'upstream_result')
        first=runner._build_attention_metadata(2,2,1)[0]['layer0']
        self.assertEqual(runtime.pool.ends,{'a':1,'b':1})
        runner.length=2;update(['b','a'])
        second=runner._build_attention_metadata(2,2,1)[0]['layer0']
        self.assertEqual(second._ring['slots'].tolist(),[2049,1])
        self.assertEqual(first._ring['slots'].data_ptr(),second._ring['slots'].data_ptr())
        saved=dict(runtime.pool.ends)
        dummy=runner._dummy_run()[0]['layer0']
        self.assertEqual(dummy._ring['slots'].tolist(),[-1])
        self.assertEqual(saved,runtime.pool.ends)
        update(['c','b'],preempted=['a'])
        self.assertEqual(runtime.pool.owners,{'b':1,'c':0})
        for c in cache.values():
            c[0].fill_(2);c[1].fill_(3);c[2].fill_(4)
        runner._init_kv_zero_meta();runner._zero_block_ids([3,5])
        for c in cache.values():
            self.assertTrue(torch.all(c[0]==2));self.assertTrue(torch.all(c[1]==3))
            self.assertTrue(torch.all(c[2][3]==0));self.assertTrue(torch.all(c[2][4]==4))

    def test_reject_missing_worker_hook_and_over_budget(self):
        runner=fake_runner();specs=runner.get_kv_cache_spec();conf=NS(specs=specs,num_blocks=12)
        with self.assertRaisesRegex(RuntimeError,'reservation absent'):
            runner._allocate_kv_cache_tensors(conf)
        runner._ring_budget_reserved=True;runner._ring_indexer_budget=1
        with self.assertRaisesRegex(RuntimeError,'exceeds reserved budget'):
            runner._allocate_kv_cache_tensors(conf)

    def test_disabled_hooks_do_not_replace_methods(self):
        ring.ENABLED=False
        class Dummy:
            def determine_available_memory(self):return 10
        original=Dummy.determine_available_memory
        ring.install_worker(Dummy);ring.install_runner(Dummy)
        self.assertIs(Dummy.determine_available_memory,original)


if __name__=='__main__':unittest.main(verbosity=2)
