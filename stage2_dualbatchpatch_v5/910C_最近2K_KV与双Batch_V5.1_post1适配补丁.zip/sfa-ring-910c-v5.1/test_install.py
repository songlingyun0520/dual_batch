"""Installer dry run, rollback and version rejection on disposable trees."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent


class InstallTests(unittest.TestCase):
    def fixture(self, folder, post1=False):
        root=Path(folder)/'vllm_ascend'
        (root/'attention').mkdir(parents=True);(root/'worker').mkdir()
        # Reconstruct V4 by deleting the four insertion-only diff hunks.
        s=(ROOT/'sfa_v1.py').read_text()
        hunks=(ROOT/'V4_to_V5.patch').read_text().splitlines(True)
        added=[];current=[]
        for line in hunks:
            if line.startswith('+') and not line.startswith('+++'):
                current.append(line[1:])
            elif current:
                added.append(''.join(current));current=[]
        if current:added.append(''.join(current))
        for block in added:
            assert s.count(block)==1
            s=s.replace(block,'',1)
        (root/'attention'/'sfa_v1.py').write_text(s)
        manifest=json.loads((ROOT/'package_manifest.json').read_text())
        assert hashlib.sha256(s.encode()).hexdigest() in manifest['accepted_sfa']
        reference=ROOT/'reference'/'post1' if post1 else ROOT/'reference'
        shutil.copy2(reference/'model_runner_v1.py',root/'worker'/'model_runner_v1.py')
        if post1:
            shutil.copy2(reference/'worker.py',root/'worker'/'worker.py')
        else:
            (root/'worker'/'worker.py').write_text('class NPUWorker:\n    def determine_available_memory(self):\n        return 1000000000\n')
        return root

    def run_installer(self,root,*args,ok=True):
        result=subprocess.run([sys.executable,str(ROOT/'apply_ring_patch.py'),'--root',str(root),*args],capture_output=True,text=True)
        if ok:self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        else:self.assertNotEqual(result.returncode,0)
        return result

    def test_dry_run_apply_idempotent_restore(self):
        with tempfile.TemporaryDirectory() as folder:
            root=self.fixture(folder)
            originals={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*.py')}
            self.run_installer(root)
            self.assertEqual(originals,{str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*.py')})
            self.run_installer(root,'--apply')
            self.run_installer(root,'--apply')
            record=json.loads((root/'sfa_ring_v5_install.json').read_text())
            self.assertEqual(len(record),5)
            for item in record:
                p=root/item['relative'];self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),item['new_sha256'])
            self.run_installer(root,'--restore')
            self.run_installer(root,'--restore','--apply')
            self.assertEqual(originals,{str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*.py')})

    def test_unknown_runner_rejected_before_any_write(self):
        with tempfile.TemporaryDirectory() as folder:
            root=self.fixture(folder);p=root/'worker'/'model_runner_v1.py'
            p.write_text(p.read_text()+'\n# other revision\n')
            before={str(p):p.read_bytes() for p in root.rglob('*') if p.is_file()}
            self.run_installer(root,'--apply',ok=False)
            self.assertEqual(before,{str(p):p.read_bytes() for p in root.rglob('*') if p.is_file()})

    def test_official_post1_apply_preserves_upstream_fix_and_restores(self):
        with tempfile.TemporaryDirectory() as folder:
            root=self.fixture(folder,post1=True)
            originals={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*.py')}
            result=self.run_installer(root)
            self.assertIn('Recognized runner: vLLM-Ascend v0.23.0.post1',result.stdout)
            self.assertEqual(originals,{str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*.py')})
            self.run_installer(root,'--apply')
            for name in ['model_runner_v1.py','worker.py']:
                p=root/'worker'/name
                self.assertTrue(p.read_bytes().startswith(originals['worker/'+name]))
            self.run_installer(root,'--apply')
            self.run_installer(root,'--restore','--apply')
            self.assertEqual(originals,{str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*.py')})

    def test_modified_post1_refused_with_actual_hash(self):
        with tempfile.TemporaryDirectory() as folder:
            root=self.fixture(folder,post1=True);p=root/'worker'/'model_runner_v1.py'
            p.write_text(p.read_text()+'\n# unreviewed derivative\n')
            before={str(f):f.read_bytes() for f in root.rglob('*') if f.is_file()}
            result=self.run_installer(root,'--apply',ok=False)
            self.assertIn(hashlib.sha256(p.read_bytes()).hexdigest(),result.stderr)
            self.assertIn(str(p),result.stderr)
            self.assertEqual(before,{str(f):f.read_bytes() for f in root.rglob('*') if f.is_file()})


if __name__=='__main__':unittest.main(verbosity=2)
